# Announcements

Announcements are global messages, which can be used to broadcast important news to the users. Latest announcement will be shown in the top of most forum pages.

Available layouts for the announcements are:

* Announcement/Edit - Edit announcement (available only for global moderators and administrators).
* Announcement/Item - Display announcement.
* Announcement/List - Display list of announcements.
* Announcement/List/Row - Display one row or item in the list of announcements.
