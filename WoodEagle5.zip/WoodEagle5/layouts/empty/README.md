# Empty

Empty template file which can be used for debugging purposes for example when layout isn't showing up.
This can happen for example when user doesn't have permissions to display content in the layout.
